<?php

class MailSender {
	
	const DB_HOST = 'localhost';
	const DB_LOGIN = 'root';
	const DB_PASSWORD = 'root';
	const DB_NAME = 'testTaskFinit';
	protected $_db;
	
	function __construct() {
		$this->_db = new mysqli( self::DB_HOST, self::DB_LOGIN, self::DB_PASSWORD, self::DB_NAME ) or exit('connect error: '.$this->_db->connect_error );
	}
	
	function __destruct() {
		$this->_db->close();
	}
	
	public function getUserGroup1() {
		$sql = "
			SELECT u.first_name, u.second_name, u.middle_name, u.email
			FROM users AS u
			INNER JOIN login_source AS ls ON u.id = ls.user_id
			GROUP BY user_id
		";
		
		$res = $this->_db->query( $sql );
		if( !is_object( $res ) ) {
			echo 'query error: '.$this->_db->error;
			return false;
		}
		
		$userGroup1 = $res->fetch_all( MYSQLI_ASSOC );
		
		return $userGroup1;
	}
	
	public function getUserGroup2() {
		$sql = "
			SELECT u.first_name, u.second_name, u.middle_name, u.email, COUNT(*) AS cntAuth
			FROM users AS u
			INNER JOIN login_source AS ls ON u.id = ls.user_id
			WHERE (TO_DAYS(NOW()) - TO_DAYS(tms)) <= 30
			GROUP BY user_id
		";
		
		$res = $this->_db->query( $sql );
		if( !is_object( $res ) ) {
			echo 'query error: '.$this->_db->error;
			return false;
		}
		
		$userGroup2 = array();
		while( $row = $res->fetch_assoc() ) {
			if( $row['cntAuth'] > 2 ) {
				$userGroup2[] = $row;
			}
		}
		
		return $userGroup2;
	}
	
	public function getUserGroup3() {
		$sql = "
			SELECT a.title, a.date_start, a.date_end
			FROM actions AS a
			WHERE a.id = 1
		";
		
		$res = $this->_db->query( $sql );
		if( !is_object( $res ) ) {
			echo 'query error: '.$this->_db->error;
			return false;
		}
		
		$action = $res->fetch_assoc();
		$date_start = $action['date_start'];
		$date_end = $action['date_end'];
		
		
		
		$sql = "
			SELECT u.first_name, u.second_name, u.middle_name, u.email
			FROM users AS u
			INNER JOIN login_source AS ls ON u.id = ls.user_id
			WHERE ls.tms < $date_start OR (ls.tms > ($date_end+1) AND (TO_DAYS(NOW()) - TO_DAYS(tms)) <= 30)
			GROUP BY u.id
		";
		
		$res = $this->_db->query( $sql );
		if( !is_object( $res ) ) {
			echo 'query error: '.$this->_db->error;
			return false;
		}
		
		$userGroup3['action'] = $action;
		while( $row = $res->fetch_assoc() ) {
			$userGroup3[] = $row;
		}
		
		return $userGroup3;
		
		
	}
	
	public function sendMail( $group ) {
		
		$to = '';
		$subject = 'Тестовая рассылка';
		$message = '';
		
		switch( $group ) {
			case 'a':
				$userGroup1 = $this->getUserGroup1();
				foreach( $userGroup1 as $k_userGroup1 => $v_userGroup1 ) {
					$to = $v_userGroup1['email'];
					$fio = $v_userGroup1['second_name'].' '.$v_userGroup1['first_name'].' '.$v_userGroup1['middle_name'];
					$message = "Здравствуйте, $fio, Вы давно не появлялись на сервисе, узнайте последние новости по ссылке: https://google.ru";
					
					$m = mail($to, $subject, $message );
				}
				break;
			
			case 'b':
				$userGroup2 = $this->getUserGroup2();
				foreach( $userGroup2 as $k_userGroup2 => $v_userGroup2 ) {
					$to = $v_userGroup2['email'];
					$fio = $v_userGroup2['second_name'].' '.$v_userGroup2['first_name'].' '.$v_userGroup2['middle_name'];
					$message = "Здравствуйте, $fio, у нас для вас акция, подробности можно узнать по ссылке: https://google.ru";
					
					$m = mail($to, $subject, $message );
					
				}
				break;
				
			case 'c':
				$userGroup3 = $this->getUserGroup3();
				$frst = array_shift( $userGroup3 );
				$title = $frst['title'];
				$date_end = $frst['date_end'];
				foreach( $userGroup3 as $k_userGroup3 => $v_userGroup3 ) {
					$to = $v_userGroup3['email'];
					$fio = $v_userGroup3['second_name'].' '.$v_userGroup3['first_name'].' '.$v_userGroup3['middle_name'];
					$message = "Здравствуйте, $fio, Вы выбраны для участия в акции $title. Успейте до $date_end принять участие.";
					
					$m = mail($to, $subject, $message );
				}
				break;
			
			default:
				echo 'unknown param group';
				
		}
		
		return $m;
	}
	
	
	
	function simplePrint( $a ) {
		echo '<pre>';
		var_dump( $a );
		echo '</pre>';
	}
	
	
	
	
	
	
}
?>