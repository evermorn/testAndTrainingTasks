<?php

require 'MailSender.class.php';

?>

<form method="post" action="<?= $_SERVER['REQUEST_URI']?>">
	Выберете групу пользователей: <br />
	<input type="radio" name="group" value="a" <?php if($_POST['group']=='a'){echo 'checked';} ?>> Группа А<br />
	<input type="radio" name="group" value="b" <?php if($_POST['group']=='b'){echo 'checked';} ?>> Группа B<br />
	<input type="radio" name="group" value="c" <?php if($_POST['group']=='c'){echo 'checked';} ?>> Группа C<br />
	<input type="submit" name="show" value="Показать" />
	<input type="submit" name="send" value="Отправить" />
</form>

<?php
if( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
	$a = new MailSender();
	if( $_POST['show'] ) {
		switch( $_POST['group'] ) {
			case 'a':
				$a->simplePrint( $a->getUserGroup1() ); break;
			case 'b':
				$a->simplePrint( $a->getUserGroup2() ); break;
			case 'c':
				$a->simplePrint( $a->getUserGroup3() ); break;
			default:
				echo 'unknown post param';
				
		}
	}elseif( $_POST['send'] ) {
		$res = $a->sendMail( $_POST['group'] );
		if( $res ) {
			echo 'рассылка успешно завершена';
		}else{
			echo 'произошла ошибка, рассылка прервана';
		}
	}
}

?>