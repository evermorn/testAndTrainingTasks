<?php

require 'MailSender.class.php';

$a = new MailSender();
$a->sendMail( $argv[1] );

?>