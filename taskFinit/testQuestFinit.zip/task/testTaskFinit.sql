-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.15-log - MySQL Community Server (GPL)
-- ОС Сервера:                   Win64
-- HeidiSQL Версия:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица testTaskFinit.actions
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT 'Заголовок',
  `date_start` date NOT NULL COMMENT 'Дата начала',
  `date_end` date NOT NULL COMMENT 'Дата окончания',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы testTaskFinit.actions: ~3 rows (приблизительно)
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` (`id`, `title`, `date_start`, `date_end`) VALUES
	(1, 'actionNumberOne', '2016-08-28', '2016-09-05'),
	(2, 'turboSlam', '2016-06-11', '2016-10-31'),
	(3, 'catchLuck', '2016-09-21', '2016-10-31');
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;


-- Дамп структуры для таблица testTaskFinit.login_source
CREATE TABLE IF NOT EXISTS `login_source` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `tms` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `source` enum('site','android','iphone') NOT NULL DEFAULT 'site',
  PRIMARY KEY (`id`),
  KEY `FK_login_source_users_id` (`user_id`),
  CONSTRAINT `FK_login_source_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы testTaskFinit.login_source: ~13 rows (приблизительно)
/*!40000 ALTER TABLE `login_source` DISABLE KEYS */;
INSERT INTO `login_source` (`id`, `user_id`, `tms`, `source`) VALUES
	(1, 1, '2016-07-13 16:39:45', 'iphone'),
	(2, 2, '2016-08-13 16:40:07', 'android'),
	(3, 3, '2016-10-04 16:40:21', 'site'),
	(4, 4, '2016-10-13 16:40:32', 'site'),
	(5, 1, '2016-09-15 16:47:41', 'site'),
	(6, 1, '2016-09-13 16:47:42', 'iphone'),
	(7, 1, '2016-10-11 16:47:42', 'iphone'),
	(8, 1, '2016-10-13 16:47:42', 'iphone'),
	(9, 2, '2016-09-13 16:49:23', 'android'),
	(10, 2, '2016-10-08 16:49:23', 'site'),
	(11, 2, '2016-10-12 16:49:24', 'android'),
	(12, 3, '2016-10-13 16:50:19', 'site'),
	(13, 5, '2016-10-13 20:06:18', 'site');
/*!40000 ALTER TABLE `login_source` ENABLE KEYS */;


-- Дамп структуры для таблица testTaskFinit.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `second_name` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы testTaskFinit.users: ~5 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `second_name`, `first_name`, `middle_name`, `email`) VALUES
	(1, 'Kingscross', 'Jerry', 'Parker', 'andruhlam@yandex.ru'),
	(2, 'Clark', 'Ocean', 'Kirk', 'evermorn@yandex.ru'),
	(3, 'Mister Egg', 'First', 'Just M', 'evermorn@yandex.ru'),
	(4, 'Keller', 'Joseph', 'Clorington', 'evermorn@yandex.ru'),
	(5, 'Croc', 'Alan', 'Smith', 'evermorn@yandex.ru');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


-- Дамп структуры для таблица testTaskFinit.user_actions
CREATE TABLE IF NOT EXISTS `user_actions` (
  `user_id` int(10) unsigned NOT NULL,
  `action_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`action_id`),
  KEY `FK_user_actions_actions_id` (`action_id`),
  CONSTRAINT `FK_user_actions_actions_id` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`),
  CONSTRAINT `FK_user_actions_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы testTaskFinit.user_actions: ~8 rows (приблизительно)
/*!40000 ALTER TABLE `user_actions` DISABLE KEYS */;
INSERT INTO `user_actions` (`user_id`, `action_id`) VALUES
	(1, 1),
	(2, 1),
	(3, 1),
	(1, 2),
	(2, 2),
	(4, 2),
	(1, 3),
	(3, 3);
/*!40000 ALTER TABLE `user_actions` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
